Author:     John Maksuta
Course:     CS250-801 Spring 2024
Instructor: Professor Pallickara
Date:       2024-01-27
Assignment: Homework 1

Description:
This is my mock submission for the HW1.
It is just a stub main, with a 'Hello World' output that is commented out.