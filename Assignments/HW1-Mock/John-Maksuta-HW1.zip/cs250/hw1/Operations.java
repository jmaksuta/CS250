package cs250.hw1;

public class Operations {

    public static void main(String[] args) {
        // System.out.println("Hello World");
    }

}